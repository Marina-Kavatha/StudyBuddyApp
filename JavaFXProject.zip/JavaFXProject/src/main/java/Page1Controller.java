package main.java;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Page1Controller {

    @FXML
    private Button btnSeeHow;

    @FXML
    private Button btnAboutUs;

    @FXML
    private Button btnNewsTips;

    @FXML
    private Button btnLogin;

    @FXML
    private void handleSeeHow(ActionEvent event) throws IOException {
        switchScene(event, "/Page2.fxml");
    }

    @FXML
    private void handleSeeHowMessage(ActionEvent event) {
        System.out.println("Μετάβαση στη σελίδα Δες Πως");
        // Κώδικας για φόρτωση της Page2.fxml
    }

    @FXML
    private void handleAboutUs(ActionEvent event) {
        System.out.println("Μετάβαση στη σελίδα Ποιοι Είμαστε");
    }

    @FXML
    private void handleNewsTips(ActionEvent event) {
        System.out.println("Μετάβαση στη σελίδα Νέα & Συμβουλές");
    }

    @FXML
    private void handleLogin(ActionEvent event) throws IOException {
        System.out.println("Μετάβαση στη σελίδα Συνδέσου Εδώ");
        switchScene(event, "/Page2.fxml");
        }

        @FXML
        private void handleGoToPage2(ActionEvent event) throws IOException {
        switchScene(event, "/Page2.fxml");
        }

        private void switchScene(ActionEvent event, String fxmlFile) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource(fxmlFile));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
}




