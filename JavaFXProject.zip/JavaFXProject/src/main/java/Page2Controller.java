package main.java;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.event.ActionEvent;

public class Page2Controller {

    public void goToPage1(ActionEvent event) throws Exception {
        Main.switchScene("/main/java/resources/Page1.fxml");
    }
    @FXML
    private Button btnBack;

    @FXML
    private void handleBackButton() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/main/java/resources/Page1.fxml")));
        stage.setScene(scene);
    }

    @FXML
    private VBox infoBox1;

    @FXML
    private VBox infoBox2;

    @FXML
    private Button btnLeftArrow;

    @FXML
    private Button btnRightArrow;

    @FXML
    private Button btnLeft;

    @FXML
    private Button btnRight;

    @FXML
    private VBox vbox1, vbox2, vbox3; // Τα VBox σου

    private int currentIndex = 0; // Δείκτης του ενεργού VBox
    private VBox[] vboxes;

    @FXML
    public void initialize() {
        vboxes = new VBox[]{vbox1, vbox2, vbox3}; // Πρόσθεσε όλα τα VBox εδώ
        updateVisibleVBox();
    }

    @FXML
    private void handleLeftArrow(ActionEvent event) {
        currentIndex = (currentIndex - 1 + vboxes.length) % vboxes.length;
        updateVisibleVBox();
    }

    @FXML
    private void handleRightArrow(ActionEvent event) {
        currentIndex = (currentIndex + 1) % vboxes.length;
        updateVisibleVBox();
    }

    private void updateVisibleVBox() {
        for (int i = 0; i < vboxes.length; i++) {
            vboxes[i].setVisible(i == currentIndex);
        }
    }


}


